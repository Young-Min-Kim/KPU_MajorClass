CREATE TABLE accounts(
	id varchar(100) not null,
	name varchar(100) not null,
	passwd varchar(100) not null,
	email varchar(100) not null,
	introduce varchar(1000),
	PRIMARY KEY (id)
	);

CREATE TABLE projects(
	userid varchar(100) not null,
	proj_name varchar(200) not null,
	number int not null,
	PRIMARY KEY (proj_name)
	);

CREATE TABLE to_do_list(
	listname varchar(500) not null,
	number int not null,
	proj_name varchar(200) not null,
	PRIMARY KEY (listname)
	);

CREATE TABLE to_do(
	todoname varchar(500) not null,
	listname varchar(500),
	sequence int,
	PRIMARY KEY (todoname)
	);
	
drop table projects;
drop table to_do_list;
drop table to_do;

SELECT COUNT(userid) FROM projects WHERE userid = "id";
select * from projects;
INSERT INTO projects VALUES ("id","������Ʈ1",1);
SELECT proj_name FROM projects WHERE userid ="id" AND number = 1