package dto;
 
public class Book implements java.io.Serializable{
    private String bookId;//���� ���̵�
    private String name; //���� �̸�
    private Integer unitPrice;// ����
    private String description;//����
    private String author;//����
    private String publisher;//���ǻ�
    private String category;//�з�
    private long unitsInStock;//��� ��
    private long totalPages;//������ �� 
    private String releaseDate;//������
    private String condition; //�Ż�ǰ �߰�ǰ ���ǰ 
    public Book() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public Book(String booktId, String name, Integer unitPrice) {
        this.bookId = booktId;
        this.name = name;
        this.unitPrice = unitPrice;
    }
 
    public String getBookId() {
        return bookId;
    }
    public void setBookId(String booktId) {
        this.bookId = booktId;
    }
    
    public String getAuthor() {
        return author;
    }
 
    public void setAuthor(String author) {
        this.author = author;
    }
 
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getUnitPrice() {
        return unitPrice;
    }
    public void setUnitPrice(Integer unitPrice) {
        this.unitPrice = unitPrice;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getPublisher() {
        return publisher;
    }
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public long getUnitsInStock() {
        return unitsInStock;
    }
    public void setUnitsInStock(long unitsInStock) {
        this.unitsInStock = unitsInStock;
    }
    public long getTotalPages() {
        return totalPages;
    }
    public void setTotalPages(long totalPages) {
        this.totalPages = totalPages;
    }
    public String getReleaseDate() {
        return releaseDate;
    }
    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }
    public String getCondition() {
        return condition;
    }
    public void setCondition(String condition) {
        this.condition = condition;
    }
    
}