text = "Life is too shortyou need java"
text2 = text.replace("java","python")
print(text2)