numbers = [1, 2, 3, 4, 5]
result = [i*2 for i in numbers if i % 2 == 1]
print(result)