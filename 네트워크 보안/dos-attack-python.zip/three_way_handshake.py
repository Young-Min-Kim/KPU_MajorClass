from scapy.all import *

ip = IP(dst="192.168.0.40")
tcp = TCP(sport=RandNum(1024, 65535), dport=80, flags='S')
syn = ip/tcp
syn_ack = sr1(syn)

ack = ip/TCP(sport = syn_ack[TCP].dport, dport = 80, flags = 'A', seq = syn_ack[TCP].ack, ack = syn_ack[TCP].seq+1)
send(ack)
