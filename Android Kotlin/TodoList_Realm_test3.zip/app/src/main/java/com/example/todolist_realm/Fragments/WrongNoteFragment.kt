package com.example.todolist_realm.Fragments

import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import android.widget.RadioGroup
import android.widget.Toast
import com.example.todolist_realm.Activities.EditActivity
import com.example.todolist_realm.Activities.MainActivity
import com.example.todolist_realm.R
import com.example.todolist_realm.Word
import com.example.todolist_realm.Wrong
import com.example.todolist_realm.WrongListAdapter
import io.realm.Realm
import io.realm.Sort
import io.realm.kotlin.where
import kotlinx.android.synthetic.main.fragment_wrong_note.*
import org.jetbrains.anko.startActivity


class WrongNoteFragment : Fragment() {

    val realm = Realm.getDefaultInstance()
    val realmResult by lazy {
        realm.where<Wrong>().distinct("word").findAll().sort("word", Sort.ASCENDING)
    }
    lateinit var listView: ListView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_wrong_note, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listView = view.findViewById(R.id.listView)
        val adapter = WrongListAdapter(realmResult)
        listView.adapter = adapter

        listView.setOnItemClickListener { parent, view, position, id ->
            // 할 일 수정
            val dlgBuilder = AlertDialog.Builder(context)
            dlgBuilder.setTitle("단어를 삭제할까요?")

            dlgBuilder.setPositiveButton("삭제") { _, _ ->
                realm.beginTransaction()
                val wrong = realm.where<Wrong>().equalTo("id", id)!!.findFirst()!!
                var wrongword=wrong.word
                while(true) {
                   try {
                       val wrong = realm.where<Wrong>().equalTo("word", wrongword)!!.findFirst()!!
                   }catch (e:KotlinNullPointerException) {
                        break
                   }
                    val wrong = realm.where<Wrong>().equalTo("word", wrongword)!!.findFirst()!!
                    wrong.deleteFromRealm()
                }
                realm.commitTransaction()
            }.setNegativeButton("취소") { _, _ -> }.show()
        }

    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (realmResult.size > 0) {
            emptyLayout.visibility = View.GONE
            listView.visibility = View.VISIBLE
        } else {
            emptyLayout.visibility = View.VISIBLE
            listView.visibility = View.GONE
        }
    }
}