package com.example.todolist_realm.Activities

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.fragment.app.Fragment
import com.example.todolist_realm.*
import com.example.todolist_realm.Fragments.QuizFragment
import com.example.todolist_realm.Fragments.NoteFragment
import com.example.todolist_realm.Fragments.SearchFragment
import com.example.todolist_realm.Fragments.WrongNoteFragment
import io.realm.Realm
import io.realm.kotlin.where
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_search.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.yesButton

class MainActivity : AppCompatActivity() {

    private val noteFragment = NoteFragment()
    private val wrongNoteFragment = WrongNoteFragment()
    private val quizFragment = QuizFragment()
    private val searchFragment = SearchFragment()
    private var currentFragment: Fragment = noteFragment

    val realm = Realm.getDefaultInstance()
    val serviceIntent by lazy {
        Intent(this, ScreenService::class.java)
    }
    private val sharedPref by lazy {
        getSharedPreferences("setting", Context.MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startService(serviceIntent)

        supportFragmentManager.beginTransaction().apply {
            add(R.id.container, noteFragment)
            add(R.id.container, wrongNoteFragment)
            hide(wrongNoteFragment)
            add(R.id.container, quizFragment)
            hide(quizFragment)
            add(R.id.container, searchFragment)
            hide(searchFragment)
        }.commit()
        supportActionBar?.title = "단어장"
        bottomNavigation.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.tab_note -> { // 단어장 탭
                    if (currentFragment != noteFragment) {
                        supportFragmentManager.beginTransaction().apply {
                            show(noteFragment)
                            hide(currentFragment)
                        }.commit()
                        currentFragment = noteFragment
                        supportActionBar?.title = "단어장"
                    }
                    true
                }
                R.id.tab_wrong_note -> { // 오답노트 탭
                    if (currentFragment != wrongNoteFragment) {
                        supportFragmentManager.beginTransaction().apply {
                            show(wrongNoteFragment)
                            hide(currentFragment)
                        }.commit()
                        currentFragment = wrongNoteFragment
                        supportActionBar?.title = "오답노트"
                    }
                    true
                }
                R.id.tab_quiz -> { // 퀴즈 탭
                    if (currentFragment != quizFragment) {
                        supportFragmentManager.beginTransaction().apply {
                            show(quizFragment)
                            hide(currentFragment)
                        }.commit()
                        currentFragment = quizFragment
                        supportActionBar?.title = "퀴즈"
                    }
                    true
                }
                R.id.tab_search -> { // 단어검색 탭
                    if (currentFragment != searchFragment) {
                        supportFragmentManager.beginTransaction().apply {
                            show(searchFragment)
                            hide(currentFragment)
                        }.commit()
                        currentFragment = searchFragment
                        supportActionBar?.title = "단어검색"
                    }
                    true
                }
                else -> false
            }
        }
    }

    fun searchWord(word: String) {
        supportFragmentManager.beginTransaction().apply {
            show(searchFragment)
            hide(currentFragment)
        }.commit()
        currentFragment = searchFragment
        supportActionBar?.title = "단어검색"

        // 설정 사이트 확인
        when (sharedPref.getInt("site", 0)) {
            0 -> webView.loadUrl("http://en.dict.naver.com/#/search?range=all&query=$word")
            1 -> webView.loadUrl("http://dic.daum.net/search.do?q=$word")
        }


        bottomNavigation.selectedItemId = R.id.tab_search
    }

    override fun onDestroy() {
        super.onDestroy()
        realm.close()
    }

    override fun onResume() {
        super.onResume()
        when(sharedPref.getInt("useLockscreen", 1)) {
            1 -> startService(serviceIntent) // 잠금 화면 사용
            0 -> stopService(serviceIntent) // 잠금 화면 사용하지 않음
        }
        webView?.let {
            when (sharedPref.getInt("site", 0)) {
                0 -> webView.loadUrl("http://dict.naver.com/")
                1 -> webView.loadUrl("http://dic.daum.net/")
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        val mInflater = getMenuInflater()
        mInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        when (item.itemId) {
            R.id.about ->{
                alert("팀정보: 헬로우 워드\n 이메일: dldudco2@gmail.com\nDeveloped By 김영민, 이영채, 최성훈") { //다이얼로그 표시
                    yesButton {}
                }.show()
            }
            R.id.settings ->{
                startActivity<SettingsActivity>()
            }
            R.id.help ->{
                startActivity<HelpActivity>()
            }
            R.id.reset-> {
                realm.beginTransaction()
                while (true){
                    try {
                        var wrong = realm.where<Wrong>().findFirst()!!
                        wrong.deleteFromRealm()
                    }catch (e:KotlinNullPointerException){
                        break
                    }
                }
                realm.commitTransaction()
                alert("오답노트가 초기화 되었습니다.") {
                    yesButton {}
                }.show()
            }
        }
        return false
    }

}
