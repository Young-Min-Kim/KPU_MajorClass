package com.example.todolist_realm.Fragments
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebViewClient
import com.example.todolist_realm.R
import kotlinx.android.synthetic.main.fragment_search.*


class SearchFragment : Fragment() {

    private val sharedPref by lazy {
        context?.getSharedPreferences("setting", Context.MODE_PRIVATE)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        webView.apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
        }

        when (sharedPref?.getInt("site", 0)) {
            0 -> webView.loadUrl("http://dict.naver.com/")
            1 -> webView.loadUrl("http://dic.daum.net/")
            2 -> webView.loadUrl("http://dic.daum.net/")
        }

        backButton.setOnClickListener {
            if (webView.canGoBack()) {
                webView.goBack()
            }
        }
    }
}
