package com.example.todolist_realm.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.todolist_realm.R
import kotlinx.android.synthetic.main.activity_help.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.yesButton

class HelpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)
        helpadd.setOnClickListener {
            alert("- 단어 추가\n\n"+
                    "1. 처음 화면에서 오른쪽 하단에 있는 '+' 버튼을 클릭하십시오. " +
                    "\n2. 추가할 단어와 뜻을 입력하신 후 완료버튼을 선택하시면 추가가 완료됩니다.") { //다이얼로그 표시
                yesButton {}
            }.show()
        }
        helpdelete.setOnClickListener {
            alert("- 단어 삭제\n\n"+
                    "1. 처음 화면에서 삭제할 단어를 선택하십시오. " +
                    "\n2. 왼쪽 하단에 있는 휴지통 아이콘을 선택하시면 단어가 삭제됩니다.") { //다이얼로그 표시
                yesButton {}
            }.show()
        }
        helpchange.setOnClickListener {
            alert("- 단어 수정\n\n"+
                    "1. 처음 화면에서 수정할 단어를 선택하십시오.  " +
                    "\n2. 단어와 뜻을 수정하신 후 완료버튼을 누르시면 수정이 완료됩니다.") { //다이얼로그 표시
                yesButton {}
            }.show()
        }
        helpwrong.setOnClickListener {
            alert("- 오답 노트\n\n"+
                    "잠금화면에서 틀린 문제들이 노트에 자동으로 추가가 됩니다." +
                    "오답 노트에서 단어를 선택하시면 삭제가 가능합니다.\n"+
                    "\n오답 노트를 초기화 하시려면, 우측 상단의 옵션 버튼을 통해 초기화를 하실 수 있습니다.") { //다이얼로그 표시
                yesButton {}
            }.show()
        }
        helpsetting.setOnClickListener {
            alert("- 어플리케이션 설정\n\n"+
                    "초기 화면 우측 상단의 'Settings'를 통해 어플리케이션의 다양한 기능을 설정할 수 있습니다.\n" +
                    "\n잠금화면 설정등 다양한 설정을 포함합니다.") { //다이얼로그 표시
                yesButton {}
            }.show()
        }
        helperror.setOnClickListener {
            alert("- 오류 발생시 대처 방법\n\n"+
                    "오류 발생시 dldudco2@gmail.com으로 이메일 주시면 신속하게 해결하겠습니다.") { //다이얼로그 표시
                yesButton {}
            }.show()
        }
        helpquiz.setOnClickListener {
            alert("- 퀴즈 기능\n\n"+
                    "우측 상단 옵션의 설정에서 잠금화면 설정을 통해 잠금화면에서의 사용을 설정하실 수 있습니다.\n\n"+
                    "설정을 통해 화면이 켜지면 퀴즈를 맞출 수 있으며 세 번째 퀴즈 탭에서도 맞출 수 있습니다.\n"+
                    "퀴즈에서 단어와 뜻을 변경하는 기능도 설정에서 변경 가능합니다.") { //다이얼로그 표시
                yesButton {}
            }.show()
        }
        helpsearch.setOnClickListener {
            alert("- 단어 검색\n\n"+
                    "단어장에서 사전에서 검색하고 싶은 단어를 길게 터치하면 단어가 검색됩니다.\n\n" +
                    "마지막 탭에서도 사전을 통해 단어 검색이 가능합니다.") { //다이얼로그 표시
                yesButton {}
            }.show()
        }
    }

}
