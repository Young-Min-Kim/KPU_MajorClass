package com.example.todolist_realm.Activities

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import com.example.todolist_realm.R
import com.example.todolist_realm.Word
import com.example.todolist_realm.Wrong
import io.realm.Realm
import io.realm.Sort
import io.realm.kotlin.createObject
import io.realm.kotlin.where
import kotlinx.android.synthetic.main.activity_lockscreen.*

class LockscreenActivity : Activity() {
    companion object {
        const val TYPE_WORD = 0
        const val TYPE_MEAN = 1
    }
    val sharedPref by lazy {
        getSharedPreferences("setting", Context.MODE_PRIVATE)
    }
    val realm = Realm.getDefaultInstance()
    // DB에서 워드 정보 가져오기
    val realmResult by lazy {
        realm.where<Word>().findAll().sort("word", Sort.ASCENDING)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        setContentView(R.layout.activity_lockscreen)

        val type = sharedPref.getInt("questionType", 0)

        val buttons = arrayOf(
            btn_answer1, btn_answer2, btn_answer3, btn_answer4)

        val indexList = getIndexList() // 무작위로 인덱스 4개를 뽑음

        var indexOfQuestion = 0
        var indexOfAnswer = 1

        // 영어단어 맞추면 질문과 답 인덱스를 바꾼다.
        if (type == TYPE_MEAN) {
            indexOfQuestion = 1
            indexOfAnswer = 0
        }

        val question = realmResult[indexList[0]]?.get(indexOfQuestion).toString() // 출제될 문제
        val answer = realmResult[indexList[0]]?.get(indexOfAnswer).toString() // 출제 문제의 정답

        tv_word.text = question

        indexList.shuffle() // 답의 위치를 무작위로 배치하기 위함

        // 버튼의 텍스트를 다른 단어들의 뜻과 정답으로 변경
        for ((i, button) in buttons.withIndex()) {
            button.text = realmResult[indexList[i]]?.get(indexOfAnswer).toString()
            button.setOnClickListener {
                if (button.text == answer) { // 정답을 누를 때
                    val oToast = Toast.makeText(this, "정답", Toast.LENGTH_SHORT)
                    val toastLayout = layoutInflater.inflate(R.layout.toast, null)
                    oToast.view = toastLayout
                    oToast.show()
                    val remove = when(type) {
                        TYPE_WORD -> {
                            realm.where<Wrong>().equalTo("word", question).findFirst()
                        }
                        TYPE_MEAN -> {
                            realm.where<Wrong>().equalTo("word", answer).findFirst()
                        }
                        else -> null
                    }
                    remove?.let { // 오답노트에 맞춘 단어가 있다면 삭제
                        deleteWord(it)
                    }
                    finish()
                } else { // 오답을 누를 때
                    val xToast = Toast.makeText(this, "오답", Toast.LENGTH_SHORT)
                    val toastLayout = layoutInflater.inflate(R.layout.x_toast, null)
                    xToast.view = toastLayout
                    xToast.show()
                    when(type) {
                        TYPE_WORD -> {
                            insertWord(question, answer) // 오답노트에 삽입
                        }
                        TYPE_MEAN -> {
                            insertWord(answer, question)
                        }
                    }
                    finish()
                }
            }
        }

    }

    fun insertWord(words:String, mean:String) {
        realm.beginTransaction()
        val wrong = realm.createObject<Wrong>(wrongNextId())
        wrong.word = words //값 설정
        wrong.mean = mean
        realm.commitTransaction()
    }

    fun deleteWord(word: Wrong) {
        realm.beginTransaction()
        word.deleteFromRealm()
        realm.commitTransaction()
    }

    fun getIndexList(): MutableList<Int> {
        val indexList = arrayListOf<Int>()
        for (index in 0 until realmResult.size) {
            indexList.add(index)
        }
        indexList.shuffle()
        return indexList.subList(0, 4)
    }

    private fun wrongNextId(): Int { //다음 id를 반환
        val maxId = realm.where<Wrong>().max("id")
        if (maxId != null) {
            return maxId.toInt() + 1
        }
        return 0
    }

    override fun onBackPressed() {

    }
}
