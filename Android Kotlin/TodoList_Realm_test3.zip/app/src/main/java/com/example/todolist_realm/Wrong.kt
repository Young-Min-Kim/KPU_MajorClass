package com.example.todolist_realm

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class Wrong(
    @PrimaryKey var id: Long = 0,
    var word: String = "",
    var mean: String = ""

) : RealmObject() {
    operator fun get(i: Int): Any? {
        if (i==0){
            return word
        }else if (i==1){
            return mean
        }
        return null
    }
}


