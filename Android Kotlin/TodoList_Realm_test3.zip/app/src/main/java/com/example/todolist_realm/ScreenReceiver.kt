package com.example.todolist_realm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.todolist_realm.Activities.LockscreenActivity
import io.realm.Realm
import io.realm.kotlin.where

class ScreenReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_SCREEN_OFF) { // 화면이 잠길 때
            val results = Realm.getDefaultInstance().where<Word>().findAll()
            if (results.size >= 4) { // 등록된 단어가 4개 이상일때 표시
                context.startActivity( // 잠금 화면을 표시
                    Intent(context, LockscreenActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                )
            }
        }
    }
}
