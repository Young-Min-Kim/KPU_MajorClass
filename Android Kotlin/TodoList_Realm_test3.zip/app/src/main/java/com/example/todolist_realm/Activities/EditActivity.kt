package com.example.todolist_realm.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.todolist_realm.R
import com.example.todolist_realm.Word
import io.realm.Realm
import io.realm.kotlin.createObject
import io.realm.kotlin.where
import kotlinx.android.synthetic.main.activity_edit.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.toast
import org.jetbrains.anko.yesButton

class EditActivity : AppCompatActivity() {

    val realm = Realm.getDefaultInstance()

    private fun insertMode() {
        editText.text = "단어 추가"
        deleteFab.visibility = View.GONE // 삭제 버튼을 감추기
//오류 발생시 deleteFab.hide()
        doneFab.setOnClickListener { // 완료 버튼을 클릭하면 추가
            insertWord()
        }
    }

    private fun updateMode(id: Long) {
        editText.text = "단어 수정"
// id에 해당하는 객체를 화면에 표시
        val word = realm.where<Word>().equalTo("id", id).findFirst()!!
        wordEditText1.setText(word.word)
        wordEditText2.setText(word.mean)
// 완료 버튼을 클릭하면 수정
        doneFab.setOnClickListener {
            if (word.word != wordEditText1.text.toString()
                || word.mean != wordEditText2.text.toString()) {
                if (wordEditText1.text.toString() != "" && wordEditText2.text.toString() != "") {
                    updateWord(id)
                } else {
                    toast("단어와 뜻을 입력해주세요")
                }
            } else {
                toast("입력값이 이전과 동일합니다")
            }
        }
// 삭제 버튼을 클릭하면 삭제
        deleteFab.setOnClickListener {
            deleteWord(id)
        }
    }


    private fun insertWord() {
        if (wordEditText1.text.toString() != "" && wordEditText2.text.toString() != "") {
            realm.beginTransaction() //트렌젝션 시작
            val word = realm.createObject<Word>(nextId()) //새 객체 생성
            word.word = wordEditText1.text.toString() //값 설정
            word.mean = wordEditText2.text.toString()
            realm.commitTransaction() //트랜젝션 종료
            alert("내용이 추가되었습니다.") {
                yesButton {
                    finish()
                    overridePendingTransition(R.anim.down, R.anim.exit_down)
            }
            }.show()//다이얼로그 표시
        } else {
            toast("단어와 뜻을 입력해주세요")
        }
    }

    private fun nextId(): Int { //다음 id를 반환
        val maxId = realm.where<Word>().max("id")
        if (maxId != null) {
            return maxId.toInt() + 1
        }
        return 0
    }

    private fun updateWord(id: Long) {
        realm.beginTransaction() //트렌젝션 시작
        val word = realm.where<Word>().equalTo("id", id).findFirst()!!//!!:todo는 이후부터 null이 아님
        word.word = wordEditText1.text.toString()
        word.mean = wordEditText2.text.toString()
        alert("내용이 변경되었습니다.") { //다이얼로그 표시
            yesButton {
                finish()
                overridePendingTransition(R.anim.down, R.anim.exit_down)
            }
        }.show()
        realm.commitTransaction() //트렌젝션 종료 반영
    }


    private fun deleteWord(id: Long) {
        realm.beginTransaction()
        val word = realm.where<Word>().equalTo("id", id).findFirst()!!
        word.deleteFromRealm() // deleteFromRealm 메서드로 삭제
        realm.commitTransaction()
        alert("내용이 삭제되었습니다.") {
            yesButton {
                finish()
                overridePendingTransition(R.anim.down, R.anim.exit_down)
            }
        }.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        realm.close()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        val id = intent.getLongExtra("id", -1L)//1:Int, 1L:Long, 1.0:Double, 1.0f:Float
        if (id == -1L) { //초기화 값(기본값)인 -1이 그대로 넘어오면 추가모드
            insertMode()
        } else { //중간에 변경되었으면 수정 모드
            updateMode(id)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.down, R.anim.exit_down)
    }
}
