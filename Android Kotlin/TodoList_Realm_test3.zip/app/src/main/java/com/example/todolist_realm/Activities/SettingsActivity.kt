package com.example.todolist_realm.Activities

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RadioGroup
import androidx.appcompat.app.AlertDialog
import com.example.todolist_realm.R

import kotlinx.android.synthetic.main.activity_settings.*
import kotlinx.android.synthetic.main.dialog_site_change.*
import kotlinx.android.synthetic.main.fragment_search.*


class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val sharedPref = getSharedPreferences(
            "setting", Context.MODE_PRIVATE
        )
        val editor = sharedPref.edit()


        // 사전 사이트 설정
        siteChangeButton.setOnClickListener {
            val dlgView = layoutInflater.inflate(R.layout.dialog_site_change, null)
            val dlgBuilder = AlertDialog.Builder(this)
            val siteChangeGroup = dlgView.findViewById<RadioGroup>(R.id.siteChangeGroup)
            dlgBuilder.setTitle("사전 사이트 설정")
            dlgBuilder.setView(dlgView)
            dlgBuilder.setPositiveButton("확인") { _, _ ->
                when (siteChangeGroup.checkedRadioButtonId) {
                    R.id.site1 -> {
                        editor.putInt("site", 0)
                    }
                    R.id.site2 -> {
                        editor.putInt("site", 1)
                    }
                }
                editor.commit()
                finish()
            }.setNegativeButton("취소") { _, _ -> }.show()
        }

        //잠금화면 사용-------------------
        ChangeLock.setOnClickListener {
            val dlgView = layoutInflater.inflate(R.layout.dialog_lock, null)
            val dlgBuilder = AlertDialog.Builder(this)
            val lockGroup = dlgView.findViewById<RadioGroup>(R.id.lockGroup)

            dlgBuilder.setTitle("잠금화면 설정")
            dlgBuilder.setView(dlgView)

            dlgBuilder.setPositiveButton("확인") { _, _ ->
                when (lockGroup.checkedRadioButtonId) {
                    R.id.lock1 -> {
                        editor.putInt("useLockscreen", 1)
                    }
                    R.id.lock2 -> {
                        editor.putInt("useLockscreen", 0)
                    }
                }
                editor.commit()
                finish()
            }.setNegativeButton("취소") { _, _ -> }.show()
        }


        // 단어 의미 전환
        switch1.isChecked = when (sharedPref.getInt("questionType", 0)) {
            0 -> false
            1 -> true
            else -> false
        }
        switch1.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                editor.putInt("questionType", 1)
            } else {
                editor.putInt("questionType", 0)
            }
            editor.commit()
        }
    }
}

