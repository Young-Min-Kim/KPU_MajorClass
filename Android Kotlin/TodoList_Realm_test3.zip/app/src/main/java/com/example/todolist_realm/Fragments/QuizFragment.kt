package com.example.todolist_realm.Fragments

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.todolist_realm.Activities.EditActivity
import com.example.todolist_realm.Activities.LockscreenActivity

import com.example.todolist_realm.R
import com.example.todolist_realm.Word
import com.example.todolist_realm.Wrong
import io.realm.Realm
import io.realm.Sort
import io.realm.kotlin.createObject
import io.realm.kotlin.where
import kotlinx.android.synthetic.main.fragment_quiz.*
import org.jetbrains.anko.startActivity


class QuizFragment : Fragment() {

    val sharedPref by lazy {
        context?.getSharedPreferences("setting", Context.MODE_PRIVATE)
    }
    val realm = Realm.getDefaultInstance()

    // DB에서 워드 정보 가져오기
    val realmResult by lazy {
        realm.where<Word>().findAll().sort("word", Sort.ASCENDING)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        addButton.setOnClickListener {
            context?.startActivity<EditActivity>()
            activity?.overridePendingTransition(R.anim.up, R.anim.exit_up)
        }

    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (realmResult.size >= 4) {
            // 새로운 문제 출제
            quizLayout.visibility = View.VISIBLE
            emptyLayout2.visibility = View.GONE
            updateQuiz()
        } else {
            quizLayout.visibility = View.GONE
            emptyLayout2.visibility = View.VISIBLE
        }
    }

    fun updateQuiz() {
        val type = sharedPref?.getInt("questionType", 0)

        val buttons = arrayOf(
            btn_answer1, btn_answer2, btn_answer3, btn_answer4
        )

        val indexList = getIndexList() // 무작위로 인덱스 4개를 뽑음

        var indexOfQuestion = 0
        var indexOfAnswer = 1

        // 영어단어 맞추면 질문과 답 인덱스를 바꾼다.
        if (type == LockscreenActivity.TYPE_MEAN) {
            indexOfQuestion = 1
            indexOfAnswer = 0
        }

        val question = realmResult[indexList[0]]?.get(indexOfQuestion).toString() // 출제될 문제
        val answer = realmResult[indexList[0]]?.get(indexOfAnswer).toString() // 출제 문제의 정답

        tv_word.text = question

        indexList.shuffle() // 답의 위치를 무작위로 배치하기 위함

        // 버튼의 텍스트를 다른 단어들의 뜻과 정답으로 변경
        for ((i, button) in buttons.withIndex()) {
            button.text = realmResult[indexList[i]]?.get(indexOfAnswer).toString()
            button.setOnClickListener {
                if (button.text == answer) { // 정답을 누를 때
                    val oToast = Toast.makeText(context, "정답", Toast.LENGTH_SHORT)
                    val toastLayout = layoutInflater.inflate(R.layout.toast, null)
                    oToast.view = toastLayout
                    oToast.show()
                    val remove = when (type) {
                        LockscreenActivity.TYPE_WORD -> {
                            realm.where<Wrong>().equalTo("word", question).findFirst()
                        }
                        LockscreenActivity.TYPE_MEAN -> {
                            realm.where<Wrong>().equalTo("word", answer).findFirst()
                        }
                        else -> null
                    }
                    remove?.let { // 오답노트에 맞춘 단어가 있다면 삭제
                        deleteWord(it)
                    }
                } else { // 오답을 누를 때
                    val xToast = Toast.makeText(context, "오답", Toast.LENGTH_SHORT)
                    val toastLayout = layoutInflater.inflate(R.layout.x_toast, null)
                    xToast.view = toastLayout
                    xToast.show()
                    when (type) {
                        LockscreenActivity.TYPE_WORD -> {
                            insertWord(question, answer) // 오답노트에 삽입
                        }
                        LockscreenActivity.TYPE_MEAN -> {
                            insertWord(answer, question)
                        }
                    }
                }
                // 문제를 풀면 다시 출제
                updateQuiz()
            }
        }
    }

    fun insertWord(words: String, mean: String) {
        realm.beginTransaction()
        val wrong = realm.createObject<Wrong>(wrongNextId())
        wrong.word = words //값 설정
        wrong.mean = mean
        realm.commitTransaction()
    }

    fun deleteWord(word: Wrong) {
        realm.beginTransaction()
        word.deleteFromRealm()
        realm.commitTransaction()
    }

    fun getIndexList(): MutableList<Int> {
        val indexList = arrayListOf<Int>()
        for (index in 0 until realmResult.size) {
            indexList.add(index)
        }
        indexList.shuffle()
        return indexList.subList(0, 4)
    }

    private fun wrongNextId(): Int { //다음 id를 반환
        val maxId = realm.where<Wrong>().max("id")
        if (maxId != null) {
            return maxId.toInt() + 1
        }
        return 0
    }

}
