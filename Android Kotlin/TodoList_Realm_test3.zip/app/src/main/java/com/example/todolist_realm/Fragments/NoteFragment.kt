package com.example.todolist_realm.Fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView

import com.example.todolist_realm.*
import com.example.todolist_realm.Activities.EditActivity
import com.example.todolist_realm.Activities.MainActivity

import io.realm.Realm
import io.realm.Sort
import io.realm.kotlin.createObject
import io.realm.kotlin.where

import kotlinx.android.synthetic.main.fragment_note.*
import kotlinx.android.synthetic.main.fragment_quiz.view.*
import kotlinx.android.synthetic.main.item_word.view.*

import org.jetbrains.anko.startActivity

class NoteFragment : Fragment() {

    val realm = Realm.getDefaultInstance()
    lateinit var listView: ListView

    fun initialize(){
        if(nextId() == 0) {
            val words = listOf("apple", "banana", "coconut","donut","elephant",
                "fog", "god", "hold", "ice", "join", "know")
            val mean = listOf("사과", "바나나", "코코넛","도넛", "코끼리",
                "안개", "신", "잡다", "얼음", "연결하다", "알다")

            for (i in 0 until words.size) {
                realm.beginTransaction()
                val word = realm.createObject<Word>(nextId())
                word.word = words[i] //값 설정
                word.mean = mean[i]
                realm.commitTransaction()
            }
        }
    }

    private fun nextId(): Int { //다음 id를 반환
        val maxId = realm.where<Word>().max("id")
        if (maxId != null) {
            return maxId.toInt() + 1
        }
        return 0
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_note, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listView = view.findViewById(R.id.listView)

        initialize()
        addFab.setOnClickListener {
            context?.startActivity<EditActivity>()
            activity?.overridePendingTransition(R.anim.up, R.anim.exit_up)
        }

        // 전체 단어 정보
        val realmResult =
            realm.where<Word>().findAll().sort("word", Sort.ASCENDING)

        val adapter = WordListAdapter(realmResult)
        listView.adapter = adapter
        realmResult.addChangeListener { _ -> adapter.notifyDataSetChanged() }

        listView.setOnItemClickListener { parent, view, position, id ->
            // 할 일 수정
            context?.startActivity<EditActivity>("id" to id)
            activity?.overridePendingTransition(R.anim.up, R.anim.exit_up)
        }

        listView.setOnItemLongClickListener { parent, view, position, id ->
            (activity as MainActivity).searchWord(view.text1.text as String)
            return@setOnItemLongClickListener true
        }
    }

}
